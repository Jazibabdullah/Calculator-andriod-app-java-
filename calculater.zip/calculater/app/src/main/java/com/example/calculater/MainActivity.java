package com.example.calculater;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {
     private TextView _screen;
     private String display="";
     private String currentOperater="";
     private String _result = "";
     @Override
     protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        _screen=(TextView)findViewById(R.id.textView2);
        _screen.setText(display);
     }
     protected void updateScreen()
     {
         _screen.setText(display);

     }
     protected void onClickNumber(View v){
         if(_result !=""){
             clear();
             updateScreen();
         }
         Button b =(Button) v;
         display += b.getText();
         updateScreen();
     }
     public  boolean isOperator (char op) {

         switch (op) {
             case '+':
                 return true;
             case '-':
                 return true;
             case '*':
                 return true;
             case '/':
                 return true;

             default:
                 return false;

         }
     }
     public  void onClickOperater(View v){
         if(display =="")return;

         Button b =(Button) v;

         if(_result!= ""){
             String  _display=_result;
             clear();
             display=_display;

         }
         if(currentOperater != ""){
             Log.d("Calc",""+display.charAt(display.length()-1));
             if(isOperator(display.charAt(display.length()-1))){
                 display= display.replace(display.charAt(display.length()-1),b.getText().charAt(0));
                 updateScreen();
                 return;


             }else{
                 getResult();
                 display=_result;
                 _result="";
             }
             currentOperater=b.getText().toString();

         }

         display +=b.getText();
         currentOperater =b.getText().toString();
         updateScreen();


     }
     protected void clear(){
         display="";
         currentOperater="";
         _result="";
     }

     public  void onClickClear(View v){

        clear();
        updateScreen();

     }
     private  double  operat(String a,String b,String op){

         switch (op) {
             case "+": return Double.valueOf(a) + Double.valueOf(b);
             case "-": return Double.valueOf(a) - Double.valueOf(b);
             case "*": return Double.valueOf(a) * Double.valueOf(b);
             case "/": try{
                 return Double.valueOf(a) / Double.valueOf(b);
             }catch (Exception e)
             {

                 Log.d("Calc",e.getMessage());
             }

             default:
                 return -1;
         }
     }
     protected boolean getResult(){
         if (currentOperater=="") return false ;
         String[] operation=display.split(Pattern.quote(currentOperater));
         if (operation.length < 2) return false;
         _result =String.valueOf( operat(operation[0],operation[1],currentOperater));

         return  true;
     }
     public void onClickEqual(View v){
       if(display =="")return;
       if(!getResult()) return;
       _screen.setText(display + "\n "+ String.valueOf(_result ));


     }
}
